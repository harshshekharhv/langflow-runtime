import logging
from enum import auto
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

from sqlalchemy.engine import URL, Connection, default, reflection

from ..flight.dpn import DPNClient
from .types import resolve_sql_type

try:
    # breaking change introduced in python 3.11
    from enum import StrEnum
except ImportError:
    from enum import Enum

    class StrEnum(str, Enum):
        def _generate_next_value_(name, start, count, last_values):
            """
            Return the lower-cased version of the member name.
            """
            return name.lower()


if TYPE_CHECKING:
    from adbc_driver_flightsql.dbapi import Connection as ADBC_Connection

# NOTE: methods with reflection.cache decorator cannot have types
# it breaks in sqlalchemy v1.4.51, v2 is ok

logger = logging.getLogger(__name__)


class Depth(StrEnum):
    all = auto()
    catalogs = auto()
    db_schemas = auto()
    tables = auto()
    columns = auto()


def client_from_url(url: URL) -> Tuple[DPNClient, Dict]:
    fields = url.translate_connect_args()
    params = {k.lower(): v for k, v in url.query.items()}
    return DPNClient(f"grpc://{fields.get('host')}:{fields.get('port')}"), params


class FlightSQLDialect(default.DefaultDialect):
    driver = "flightsql"

    def connect(self, client: DPNClient, **cparams):
        token = cparams.pop("token", None)
        if token is None:
            logger.error("Missing token in query params.")
            raise ValueError(
                "Only Bearer token authorization supported. "
                "Please add '?token=<jwt-token>' to the connection url."
            )
        client.authenticate(token)
        return client.connect()

    def create_connect_args(self, url: URL) -> List:
        client, opts = client_from_url(url)
        return [[client], opts]

    def _get_dbapi_connection(self, connection: Connection) -> "ADBC_Connection":
        return connection.connection

    def _get_server_version_info(self, connection: Connection) -> Any:
        dbapi_conn = self._get_dbapi_connection(connection)
        info = dbapi_conn.adbc_get_info()
        version = info.get("vendor_version", "")
        if version:
            return tuple(version.split("."))
        return None

    @reflection.cache
    def get_table_names(self, connection, schema=None, **kw):
        tables = []
        dbapi_conn = self._get_dbapi_connection(connection)
        objects = dbapi_conn.adbc_get_objects(
            depth=Depth.tables.value, db_schema_filter=schema
        )
        for chunk in objects:
            for catalog in chunk.to_pylist():
                for db_schema in catalog["catalog_db_schemas"]:
                    tables.extend(
                        [
                            table.get("table_name")
                            for table in db_schema["db_schema_tables"]
                        ]
                    )
        return tables

    @reflection.cache
    def get_columns(self, connection, table_name, schema=None, **kw):
        dbapi_conn = self._get_dbapi_connection(connection)
        table = dbapi_conn.adbc_get_table_schema(table_name, db_schema_filter=schema)
        return [self._get_column_info(field) for field in table]

    def _get_column_info(self, field):
        return {
            "name": field.name,
            "type": resolve_sql_type(field.type),
            "nullable": field.nullable,
            "default": None,
            "comment": None,
        }

    @reflection.cache
    def get_schema_names(self, connection, **kw):
        schemas = []
        dpapi_conn = self._get_dbapi_connection(connection)
        objects = dpapi_conn.adbc_get_objects(depth=Depth.db_schemas.value)
        for chunk in objects:
            for catalog in chunk.to_pylist():
                for db_schema in catalog["catalog_db_schemas"]:
                    schemas.append(db_schema["db_schema_name"])
        return schemas

    @reflection.cache
    def has_table(self, connection, table_name, schema=None, **kw):
        return table_name in self.get_table_names(connection, schema)

    def get_indexes(
        self,
        connection: Connection,
        table_name: str,
        schema: Optional[str] = None,
        **kw: Any,
    ) -> List[Dict]:
        return []

    def get_pk_constraint(
        self,
        connection: Connection,
        table_name: str,
        schema: Optional[str] = None,
        **kw: Any,
    ) -> Dict:
        return {}

    def get_foreign_keys(
        self,
        connection: Connection,
        table_name: str,
        schema: Optional[str] = None,
        **kw: Any,
    ) -> List[Dict]:
        return []

    def get_view_names(
        self, connection: Connection, schema: Optional[str] = None, **kw: Any
    ) -> List[str]:
        return []
