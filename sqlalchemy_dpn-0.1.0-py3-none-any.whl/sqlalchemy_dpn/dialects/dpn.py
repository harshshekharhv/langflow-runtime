from .base import FlightSQLDialect


class DPNDialect(FlightSQLDialect):
    name = "dpn"

    paramstyle = "qmark"
    supports_statement_cache = True
    supports_empty_insert = False

    # TODO: what else is supported ?

    @classmethod
    def import_dbapi(cls):
        from adbc_driver_flightsql import dbapi

        return dbapi

    @classmethod
    def dbapi(cls):
        # for backwards compatibility
        return cls.import_dbapi()
