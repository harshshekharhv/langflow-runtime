import pyarrow as pa
import sqlalchemy.types as sqltypes


def resolve_sql_type(t: pa.DataType):
    if pa.types.is_binary(t):
        return sqltypes.BINARY
    if pa.types.is_boolean(t):
        return sqltypes.BOOLEAN
    if pa.types.is_date(t):
        return sqltypes.DATE
    if pa.types.is_decimal(t):
        return sqltypes.DECIMAL
    if pa.types.is_floating(t):
        return sqltypes.FLOAT
    if pa.types.is_string(t):
        return sqltypes.TEXT
    if pa.types.is_time(t):
        return sqltypes.TIME
    if pa.types.is_timestamp(t):
        return sqltypes.TIMESTAMP
    if pa.types.is_interval(t):
        return sqltypes.Interval

    if any([pa.types.is_int8(t), pa.types.is_int16(t)]):
        return sqltypes.SMALLINT
    if pa.types.is_uint64(t):
        return sqltypes.BIGINT
    if pa.types.is_integer(t):
        return sqltypes.INTEGER

    raise Exception("Unsupported SQL Type")
