import warnings
from typing import Iterator, Union
from urllib.parse import urlparse

from adbc_driver_flightsql import DatabaseOptions, dbapi as flight_sql
from pyarrow.flight import ActionType, FlightClient, Location

from ._flight import AuthClientMiddlewareFactory, AuthHandler


class DPNClient:
    """A Base class for connecting to a Apache Arrow Flight Server."""

    flight_scheme: str = None
    flight_host: str = None
    flight_port: int = None
    _flight_client: FlightClient = None

    def __init__(
        self,
        flight_uri: str,
        verify: Union[str, bool] = None,
    ) -> None:
        """
        Initializes an Arrow Flight Client

        Parameters
        ----------
        flight_url: str
            URI of the flight server.
        verify: str|bool, default=True
            Either a boolean, in which case it controls wheter we verify the
            server's TLS certificate, or a string, in which case it must be a
            path to a CA bundle to use.
        """
        self.flight_uri = urlparse(flight_uri)
        self.verify = bool(verify)
        if self.verify:
            warnings.warn("verify is not implemented!")
        if "tls" in self.flight_uri.scheme:
            warnings.warn("TLS is not implemented!")

    def authenticate(self, token: str = None):
        """Perform flight handshake"""
        location = Location.for_grpc_tcp(self.flight_uri.hostname, self.flight_uri.port)
        self._auth = AuthHandler()
        self._authMiddleware = AuthClientMiddlewareFactory(token)
        self._flight_client = FlightClient(location, middleware=[self._authMiddleware])
        self._flight_client.authenticate(self._auth)

    #
    # flight server capabilities discovery

    def list_actions(self) -> Iterator[ActionType]:
        return list(self._flight_client.list_actions())

    def connect(self):
        headers = self._authMiddleware.headers
        token = self._authMiddleware.token
        return flight_sql.connect(
            self.flight_uri.geturl(),
            db_kwargs={
                DatabaseOptions.AUTHORIZATION_HEADER.value: f"Bearer {token}",
                DatabaseOptions.WITH_COOKIE_MIDDLEWARE.value: "true",
                **{
                    f"{DatabaseOptions.RPC_CALL_HEADER_PREFIX.value}{k}": v
                    for k, v in headers.items()
                },
            },
        )
