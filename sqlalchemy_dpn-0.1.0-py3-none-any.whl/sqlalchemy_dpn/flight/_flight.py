import json
import logging

from pyarrow._flight import ClientAuthReader, ClientAuthSender
from pyarrow.flight import ClientAuthHandler, ClientMiddleware, ClientMiddlewareFactory

logger = logging.getLogger(__name__)


class AuthHandler(ClientAuthHandler):
    def __init__(self):
        self.token = b""

    def authenticate(self, outgoing: ClientAuthSender, incoming: ClientAuthReader):
        outgoing.write(b"")
        response = json.loads(incoming.read())
        self.token = response["access_token"]

    def get_token(self):
        return self.token


class AuthClientMiddlewareFactory(ClientMiddlewareFactory):
    def __init__(self, token: str):
        self.headers = {}
        self.token = token

    def start_call(self, info):
        logger.debug(f"{info=}")
        return AuthClientMiddleware(self)


class AuthClientMiddleware(ClientMiddleware):
    def __init__(self, factory):
        self.factory = factory

    def sending_headers(self):
        headers = {"authorization": f"Bearer {self.factory.token}"}
        headers.update(self.factory.headers)
        logger.debug(f"sending {headers=}")
        return headers

    def received_headers(self, headers):
        logger.debug(f"received {headers=}")
        cookies = headers.get("set-cookie")
        if cookies:
            self.factory.headers.update({"cookie": ";".join(cookies)})
